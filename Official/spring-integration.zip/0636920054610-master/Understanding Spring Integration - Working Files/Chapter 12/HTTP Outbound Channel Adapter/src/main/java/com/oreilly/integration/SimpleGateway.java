package com.oreilly.integration;

public interface SimpleGateway {

	public String execute(String message);
}
