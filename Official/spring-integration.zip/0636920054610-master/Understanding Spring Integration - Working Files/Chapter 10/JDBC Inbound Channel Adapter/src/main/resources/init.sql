create table person(
	person_id int primary key,
	first_name varchar,
	last_name varchar
);

insert into person values(1, 'Kevin','Bowersox');
insert into person values(2, 'John','Doe');