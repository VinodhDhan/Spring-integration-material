package com.oreilly.integration;


public class CustomService {

	public String getPhoneNumber(Person person){
		return "867-5309";
	}
}
